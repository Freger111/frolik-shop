Аим-тренажёр
aim/index.html — игра (открыть в браузере)
plan.html — план на 14 дней
guide.html — инструкция

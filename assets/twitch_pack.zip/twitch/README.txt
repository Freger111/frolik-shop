Twitch-пак
panels/ — панели канала
alerts/ — GIF-алерты
sounds/ — звуки
offline.png — экран оффлайн
guide.html — инструкция

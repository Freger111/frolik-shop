12 аватарок 512×512 PNG с прозрачностью.
Подойдут для Twitch, YouTube, Telegram, Discord.

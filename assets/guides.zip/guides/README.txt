Два гайда (HTML, открываются в браузере):
guide_obs.html — OBS с нуля за 20 минут
guide_pc.html — ПК без тормозов
